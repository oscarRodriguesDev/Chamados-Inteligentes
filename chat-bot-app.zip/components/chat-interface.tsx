"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Send, LogOut, Bot, User } from "lucide-react"

interface Message {
  id: string
  text: string
  sender: "user" | "bot"
  timestamp: Date
}

interface ChatInterfaceProps {
  userName: string
  onLogout: () => void
}

const botResponses = [
  "Olá! Como posso ajudá-lo hoje?",
  "Estou aqui para fornecer informações úteis. O que você gostaria de saber?",
  "Posso ajudá-lo com dúvidas sobre nossos serviços, produtos ou qualquer informação geral.",
  "Interessante pergunta! Deixe-me pensar na melhor resposta para você.",
  "Baseado na sua pergunta, posso sugerir algumas opções que podem ser úteis.",
  "Essa é uma ótima questão! Vou fazer o meu melhor para esclarecer isso para você.",
  "Obrigado por perguntar! Aqui estão algumas informações que podem ajudar:",
  "Entendo sua dúvida. Vou explicar de forma clara e objetiva.",
  "Posso fornecer mais detalhes sobre esse assunto se você quiser.",
  "Espero ter esclarecido sua dúvida. Há mais alguma coisa que posso ajudar?",
]

const getBotResponse = (userMessage: string): string => {
  const message = userMessage.toLowerCase()

  if (message.includes("olá") || message.includes("oi") || message.includes("hello")) {
    return "Olá! É um prazer conversar com você. Como posso ajudá-lo hoje?"
  }

  if (message.includes("como você está") || message.includes("tudo bem")) {
    return "Estou funcionando perfeitamente, obrigado por perguntar! Como posso ajudá-lo?"
  }

  if (message.includes("ajuda") || message.includes("help")) {
    return "Claro! Estou aqui para ajudar. Posso fornecer informações sobre diversos assuntos, responder perguntas e orientá-lo. O que você precisa saber?"
  }

  if (message.includes("serviços") || message.includes("produtos")) {
    return "Oferecemos uma ampla gama de serviços digitais, incluindo desenvolvimento web, consultoria em tecnologia e suporte técnico. Gostaria de saber mais sobre algum serviço específico?"
  }

  if (message.includes("preço") || message.includes("custo") || message.includes("valor")) {
    return "Os preços variam dependendo do serviço solicitado. Para um orçamento personalizado, posso conectá-lo com nossa equipe comercial. Que tipo de serviço você tem interesse?"
  }

  if (message.includes("contato") || message.includes("telefone") || message.includes("email")) {
    return "Você pode entrar em contato conosco pelo email: contato@empresa.com ou telefone: (11) 9999-9999. Nosso horário de atendimento é de segunda a sexta, das 9h às 18h."
  }

  if (message.includes("obrigado") || message.includes("valeu") || message.includes("thanks")) {
    return "De nada! Fico feliz em poder ajudar. Se tiver mais alguma dúvida, estarei aqui!"
  }

  // Resposta padrão aleatória
  return botResponses[Math.floor(Math.random() * botResponses.length)]
}

export default function ChatInterface({ userName, onLogout }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: `Olá ${userName}! Bem-vindo ao nosso chat. Sou seu assistente virtual e estou aqui para ajudá-lo com informações sobre nossos serviços, produtos e responder suas dúvidas. Como posso ajudá-lo hoje?`,
      sender: "bot",
      timestamp: new Date(),
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputMessage.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputMessage.trim(),
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setIsTyping(true)

    // Simular delay de digitação do bot
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: getBotResponse(userMessage.text),
        sender: "bot",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, botMessage])
      setIsTyping(false)
    }, 1500)
  }

  return (
    <div className="min-h-screen chat-gradient">
      {/* Header */}
      <div className="bg-card/80 backdrop-blur-sm border-b border-border/50 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarFallback className="bg-primary text-primary-foreground">
                <Bot className="w-5 h-5" />
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="font-semibold">Assistente Virtual</h1>
              <p className="text-sm text-muted-foreground">Online</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground">Olá, {userName}</span>
            <Button variant="outline" size="sm" onClick={onLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="max-w-4xl mx-auto p-4 pb-24">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              {message.sender === "bot" && (
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    <Bot className="w-4 h-4" />
                  </AvatarFallback>
                </Avatar>
              )}

              <Card
                className={`max-w-[70%] p-3 ${
                  message.sender === "user" ? "bg-primary text-primary-foreground" : "bg-card"
                }`}
              >
                <p className="text-sm leading-relaxed">{message.text}</p>
                <p
                  className={`text-xs mt-2 ${
                    message.sender === "user" ? "text-primary-foreground/70" : "text-muted-foreground"
                  }`}
                >
                  {message.timestamp.toLocaleTimeString("pt-BR", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </Card>

              {message.sender === "user" && (
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-secondary text-secondary-foreground">
                    <User className="w-4 h-4" />
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3 justify-start">
              <Avatar className="w-8 h-8">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  <Bot className="w-4 h-4" />
                </AvatarFallback>
              </Avatar>
              <Card className="bg-card p-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                  <div
                    className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                    style={{ animationDelay: "0.1s" }}
                  ></div>
                  <div
                    className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                    style={{ animationDelay: "0.2s" }}
                  ></div>
                </div>
              </Card>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Form */}
      <div className="fixed bottom-0 left-0 right-0 bg-card/80 backdrop-blur-sm border-t border-border/50 p-4">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Digite sua mensagem..."
              className="flex-1"
              disabled={isTyping}
            />
            <Button type="submit" disabled={!inputMessage.trim() || isTyping}>
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
